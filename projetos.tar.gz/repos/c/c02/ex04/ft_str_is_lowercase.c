int	ft_str_is_lowercase(char *str)
{
	int		i;
	int		all_is_lowcase;

	all_is_lowcase = 1;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
			i++;
		else
		{	
			all_is_lowcase = 0;
			break ;
		}
	}
	return (all_is_lowcase);
}
