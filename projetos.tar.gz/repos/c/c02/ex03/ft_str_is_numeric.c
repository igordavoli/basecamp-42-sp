int	ft_str_is_numeric(char *str)
{
	int		i;
	int		all_is_num;

	all_is_num = 1;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= '0' && str[i] <= '9')
			i++;
		else
		{	
			all_is_num = 0;
			break ;
		}
	}
	return (all_is_num);
}
