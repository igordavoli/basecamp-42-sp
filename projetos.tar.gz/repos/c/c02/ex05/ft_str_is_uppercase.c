int	ft_str_is_uppercase(char *str)
{
	int		i;
	int		all_is_uppercase;

	all_is_uppercase = 1;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			i++;
		else
		{	
			all_is_uppercase = 0;
			break ;
		}
	}
	return (all_is_uppercase);
}
