int	ft_is_alpha_num(char str)
{
	int		is_apha_num;

	is_apha_num = 0;
	if (str >= 'a' && str <= 'z')
		is_apha_num = 1;
	if (str >= '0' && str <= '9')
		is_apha_num = 1;
	return (is_apha_num);
}

char	*ft_strcapitalize(char *str)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		i++;
	}
	i = 0;
	while (str[i] != '\0')
	{
		if ((str[i] >= 'a' && str[i] <= 'z') && !ft_is_alpha_num(str[i - 1])
			&& !(str[i - 1] >= 'A' && str[i - 1] <= 'Z'))
			str[i] -= 32;
		i++;
	}
	return (str);
}
