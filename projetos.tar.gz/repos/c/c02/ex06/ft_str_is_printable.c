int	ft_str_is_printable(char *str)
{
	int		i;
	int		all_is_printable;

	all_is_printable = 1;
	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] >= 32 && str[i] < 127)
			i++;
		else
		{	
			all_is_printable = 0;
			break ;
		}
	}
	return (all_is_printable);
}
