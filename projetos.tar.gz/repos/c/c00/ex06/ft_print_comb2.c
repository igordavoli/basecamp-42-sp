#include <unistd.h>

void	ft_print_numbers(int x1, int x2, int y1, int y2)
{
	if ((x1 <= y1 && x2 < y2))
	{
		write(1, &x1, 1);
		write(1, &x2, 1);
		write(1, " ", 1);
		write(1, &y1, 1);
		write(1, &y2, 1);
		if (!(x1 == '9' && x2 == '8' && y1 == '9' && y2 == '9'))
			write(1, ", ", 2);
	}
}

void	ft_generate_sec_num(int x1, int x2)
{
	int		y1;
	int		y2;

	y1 = '0';
	while (y1 <= '9')
	{
		y2 = '0';
		while (y2 <= '9')
		{				
			ft_print_numbers(x1, x2, y1, y2);
			y2++;
		}
		y1++;
	}
}

void	ft_print_comb2(void)
{
	int		x1;
	int		x2;

	x1 = '0';
	while (x1 <= '9')
	{
		x2 = '0';
		while (x2 <= '9')
		{
			ft_generate_sec_num(x1, x2);
			x2++;
		}
		x1++;
	}
}
