#include <unistd.h>

void	ft_print_number(int n, int n2, int n3)
{
	write(1, &n, 1);
	write(1, &n2, 1);
	write(1, &n3, 1);
}

void	ft_print_comb(void)
{
	char	n;
	char	n2;
	char	n3;

	n = '0';
	while (n <= '9')
	{
		n2 = '0';
		while (n2 <= '9')
		{
			n3 = '0';
			while (n3 <= '9')
			{
				if (n < n2 && n2 < n3)
				{
					ft_print_number(n, n2, n3);
					if (!(n == '7' && n2 == '8' && n3 == '9'))
						write(1, ", ", 2);
				}
				n3++;
			}
			n2++;
		}
		n++;
	}
}
