void	ft_swap(int *a, int *b)
{
	int		swp;

	swp = *a;
	*a = *b;
	*b = swp;
}
