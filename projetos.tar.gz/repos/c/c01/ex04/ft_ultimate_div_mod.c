void	ft_ultimate_div_mod(int *a, int *b)
{
	int		swp_a;

	if (*b != 0)
	{
		swp_a = *a;
		*a = *a / *b;
		*b = swp_a % *b;
	}
}
