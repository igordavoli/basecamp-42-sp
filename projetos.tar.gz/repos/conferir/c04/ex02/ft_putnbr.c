#include <unistd.h>

void	putchar(char x)
{
	write (1, &x, 1);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		putchar ('-');
		putchar ('2');
		nb = 147483648;
	}
	if (nb < 0)
	{
		nb = -nb;
		putchar('-');
	}
	if (nb < 10)
	{
		putchar (nb + '0');
	}
	else
	{
		ft_putnbr (nb / 10);
		ft_putnbr (nb % 10);
	}
}

int main()
{
	ft_putnbr(2048);
}