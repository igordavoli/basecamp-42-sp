#!/bin/sh
ls -l | sed -n "p;n"