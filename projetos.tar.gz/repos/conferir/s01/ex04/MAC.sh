#!/bin/sh
ifconfig | grep ether | cut -c15-31