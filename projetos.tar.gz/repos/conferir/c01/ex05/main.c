void	ft_putstr(char *str);

int	main(void)
{
	char *str = "alow galera\n";

	ft_putstr(str);
	return (0);
}