#include<stdio.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	y;

	y = 0;
	while (src[y] != '\0')
	{
		dest[y] = src[y];
		++y;
	}
	dest[y] = '\0';
	return (dest);
}
