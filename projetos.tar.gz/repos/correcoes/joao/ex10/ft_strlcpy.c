unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	sizeSrc;

	i = 0;
	sizeSrc = 0;
	while (src[sizeSrc] != '\0')
		sizeSrc++;
	if (size > 0)
	{
		while (src[i] != '\0' && i < (size))
		{
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
	}
	return (sizeSrc);
}
