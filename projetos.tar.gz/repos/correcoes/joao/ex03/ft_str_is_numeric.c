int	ft_str_is_numeric(char *str)
{
	int	h;
	int	z;

	h = 0;
	while (str[h] != '\0')
	{
		z = str[h];
		if (!(z >= '0' && z <= '9'))
		{
			return (0);
		}
		++h;
	}
	return (1);
}
