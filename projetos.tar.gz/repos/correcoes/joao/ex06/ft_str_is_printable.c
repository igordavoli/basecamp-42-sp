int	ft_str_is_printable(char *str)
{
	int	x;

	x = 0;
	while (str[x] != '\0')
	{
		if (!(str[x] < 127 && str[x] >= 32))
		{
			return (0);
		}
		++x;
	}
	return (1);
}
