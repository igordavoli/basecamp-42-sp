/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcarvalh <tcarvalh@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/27 02:05:27 by tcarvalh          #+#    #+#             */
/*   Updated: 2021/07/27 11:25:35 by tcarvalh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlen(char *str)
{
	unsigned int	length;

	length = 0;
	while (*(str + length) != '\0')
		length++;
	return (length);
}

unsigned int	ft_strnlen(char *str, unsigned int size)
{
	unsigned int	length;

	length = 0;
	while (length < size && str[length] != '\0')
		length++;
	return (length);
}

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	index;

	index = 0;
	while (index < n && src[index] != '\0')
	{
		dest[index] = src[index];
		index++;
	}
	while (index < n)
	{
		dest[index] = '\0';
		index++;
	}
	return (dest);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i_dest;
	unsigned int	i_src;

	i_src = ft_strlen(src);
	i_dest = ft_strnlen(dest, size);
	if (i_dest == size)
		return (i_dest + i_src);
	if (i_src + i_dest < size)
		ft_strncpy((dest + i_dest), src, i_src + 1);
	else
	{
		ft_strncpy((dest + i_dest), src, size - i_dest - 1);
		dest[size - 1] = '\0';
	}
	return (i_src + i_dest);
}
