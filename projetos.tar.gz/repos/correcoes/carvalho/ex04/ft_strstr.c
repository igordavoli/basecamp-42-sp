/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tcarvalh <tcarvalh@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/27 01:18:33 by tcarvalh          #+#    #+#             */
/*   Updated: 2021/07/27 01:43:10 by tcarvalh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	unsigned int	i_str;
	unsigned int	i_find;

	i_str = 0;
	i_find = 0;
	if (to_find[0] == '\0')
		return (str);
	while (str[i_str] != '\0')
	{
		i_find = 0;
		while (str[i_str + i_find] == to_find[i_find])
		{
			if (to_find[i_find + 1] == '\0')
				return (str + i_str);
			i_find++;
		}
		i_str++;
	}
	return (0);
}
