#!/bin/sh
cat /etc/passwd | cut -d":" -f1 | rev | sort -r
