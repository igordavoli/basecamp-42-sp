/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jramondo <jramondo@student.42sp.org.br>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/27 13:43:30 by jramondo          #+#    #+#             */
/*   Updated: 2021/07/27 14:30:12 by jramondo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	index;
	int	index2;
	int	hold_value;

	index2 = 0;
	while (index2 < size - 1)
	{	
		index = -1;
		while (++index < size - 1)
		{
			if (tab[index] > tab[index + 1])
			{
				hold_value = tab[index];
				tab[index] = tab[index + 1];
				tab[index + 1] = hold_value;
			}
		}
		index2++;
	}
}
