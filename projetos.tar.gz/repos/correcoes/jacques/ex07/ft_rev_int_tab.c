/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idavoli- <idavoli-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/23 01:51:18 by jramondo          #+#    #+#             */
/*   Updated: 2021/07/27 17:28:20 by idavoli-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	hold_value;
	int	index;

	index = -1;
	while (++index < size / 2)
	{
		hold_value = tab[size - (1 + index)];
		tab[size - (1 + index)] = tab[index];
		tab i = hold_value;
	}
}
