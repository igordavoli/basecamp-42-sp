/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idavoli- <idavoli-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/29 09:52:50 by acesar-l          #+#    #+#             */
/*   Updated: 2021/07/30 21:53:37 by idavoli-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	ft_putchar(int a)
{
	write(1, &a, 1);
}

void	ft_putnbr(int nb)
{
	int	soma;

	soma = 0;
	if (nb < 0)
	{
		write(1, "-", 1);
		nb *= -1;
		if (nb == -2147483648)
		{
			nb--;
			soma = 1;
		}
	}
	if (nb < 10)
		ft_putchar(nb + 48 + soma);
	else
	{
		ft_putnbr(nb / 10);
		ft_putnbr(nb % 10 + soma);
	}	
}

int main()
{
	ft_putnbr(2048);
}