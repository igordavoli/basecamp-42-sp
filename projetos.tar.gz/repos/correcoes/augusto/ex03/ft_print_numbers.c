/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idavoli- <idavoli-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/29 09:52:06 by acesar-l          #+#    #+#             */
/*   Updated: 2021/07/30 21:41:40 by idavoli-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	ft_print_numbers(void)
{
	int	number;

	number = '0';
	while (number <='9')
	{
		write(1, &number, 1);
		++number;
	}
}

int main()
{
	ft_print_numbers();
}
