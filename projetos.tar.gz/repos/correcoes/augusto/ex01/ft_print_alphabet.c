/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idavoli- <idavoli-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/29 09:51:43 by acesar-l          #+#    #+#             */
/*   Updated: 2021/07/30 21:36:56 by idavoli-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	ft_print_alphabet(void)
{
	char	alphabet_lower_case;
	int		i;

	alphabet_lower_case = 'a';
	i = 0;
	while (i < 26)
	{
		write(1, &alphabet_lower_case, sizeof(char));
		++alphabet_lower_case;
		++i;
	}
}
int main()
{
	ft_print_alphabet();
}