void	*ft_print_memory(void *addr, unsigned int size)
{
	return (0);
}
