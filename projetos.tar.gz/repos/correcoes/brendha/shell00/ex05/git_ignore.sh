#!/bin/sh
git ls-files --ignored --others --exclude-standard