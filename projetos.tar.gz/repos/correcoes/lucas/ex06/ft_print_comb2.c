/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idavoli- <idavoli-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/22 14:18:31 by lveiga-g          #+#    #+#             */
/*   Updated: 2021/07/29 00:10:48 by idavoli-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_put_two_char(char f, char s)
{
	write(1, &f, 1);
	write(1, &s, 1);
}

void	ft_putint(int nb, int limit)
{
	char	dez;
	char	uni;

	if (nb <= 9)
	{
		uni = nb + 48;
		ft_put_two_char('0', uni);
	}
	else if (nb <= limit)
	{
		dez = (nb / 10) + 48;
		uni = (nb % 10) + 48;
		ft_put_two_char(dez, uni);
	}
}

void	ft_print_comb2(void)
{
	int	fp;
	int	sp;

	fp = 0;
	while (fp <= 98)
	{
		sp = fp + 1;
		while (sp <= 99)
0
				write(1, ", ", 2);
			sp++;
		}
		fp++;
	}
}

int main()
{
	ft_print_comb2();
}