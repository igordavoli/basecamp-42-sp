void	*ft_print_memory(void *addr, unsigned int size)
{
	size = 0;
}