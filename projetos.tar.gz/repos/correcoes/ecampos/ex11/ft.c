void	ft_putstr_non_printable(char *str)
{
	
}