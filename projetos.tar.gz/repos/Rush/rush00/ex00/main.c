void	rush(int x, int y);

int	main(void)
{
	rush(0, 20);
	return (0);
}
