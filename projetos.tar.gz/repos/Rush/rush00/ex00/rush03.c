void	ft_putchar(char c);

void	rush(int x, int y)
{
	int		height;
	int		width;

	height = 1;
	while (height <= y)
	{	
		width = 1;
		while (width <= x)
		{
			if ((height == 1 && width == 1) || (height == y && width == 1))
				ft_putchar('A');
			else if ((width == x && height == 1) || (width == x && height == y))
				ft_putchar('C');
			else if ((width != 1 && height != y) && (width != x && height != 1))
				ft_putchar(' ');
			else
				ft_putchar('B');
			width++;
		}
		ft_putchar('\n');
		height++;
	}
}
