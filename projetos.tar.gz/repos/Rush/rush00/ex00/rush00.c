void	ft_putchar(char c);

void	rush(int x, int y)
{
	int		height;
	int		width;

	height = 1;
	while (height <= y)
	{	
		width = 1;
		while (width <= x)
		{
			if ((height == 1 && width == x) || (height == y && width == 1)
				|| (width == x && height == y) || (width == 1 && height == 1))
				ft_putchar('o');
			else if ((height == 1 && width != 1 && width != x)
				|| (height == y && width != x && width != 1))
				ft_putchar('-');
			else if ((width != 1 && height != y) && (width != x && height != 1))
				ft_putchar(' ');
			else
				ft_putchar('|');
			width++;
		}
		ft_putchar('\n');
		height++;
	}
}
