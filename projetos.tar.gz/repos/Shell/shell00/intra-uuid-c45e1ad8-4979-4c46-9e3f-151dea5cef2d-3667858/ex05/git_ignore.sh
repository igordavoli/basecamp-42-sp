#!/bin/sh
echo "$(git status --ignored --porcelain | grep '^!!' | cut -c4-)"